package com.cbozan.exception;

public class EntityException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 779084455120994640L;

	public EntityException(String message) {
		super(message);
	}
	
	
}