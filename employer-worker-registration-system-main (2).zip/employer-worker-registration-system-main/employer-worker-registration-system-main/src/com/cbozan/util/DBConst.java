package com.cbozan.util;

public abstract class DBConst {
	public static final int FNAME_LENGTH = 30;
	public static final int LNAME_LENGTH = 20;
}
